import { redirect } from "next/navigation";
import { eq } from "drizzle-orm";
import { getDb } from "../db";
import { admins } from "../db/schema";
import { getChatGPTUser, chatGPTSignInPath, type ChatGPTUser } from "./chatgpt-auth";

// Identity (who is this person?) is proven by ChatGPT sign-in (SIWC) - see
// chatgpt-auth.ts. Authorization (are they allowed to manage this site?) is a
// separate question, answered here: is their email in the admin allowlist?
//
// These two addresses are always admins, even if the `admins` table is empty
// or the database is briefly unreachable - they can always sign in and add
// more admins from the "ניהול מנהלים" screen. Keep this bootstrap list short.
export const DEFAULT_ADMIN_EMAILS = [
  "o0534169095@gmail.com",
  "0534169095@xn--4dbjbascrao3i.com",
];

function normalizeEmail(email: string): string {
  return email.trim().toLowerCase();
}

const NORMALIZED_DEFAULT_ADMINS = new Set(DEFAULT_ADMIN_EMAILS.map(normalizeEmail));

export function isDefaultAdminEmail(email: string): boolean {
  return NORMALIZED_DEFAULT_ADMINS.has(normalizeEmail(email));
}

export async function isAllowedAdminEmail(email: string): Promise<boolean> {
  const normalized = normalizeEmail(email);
  if (NORMALIZED_DEFAULT_ADMINS.has(normalized)) return true;
  const db = await getDb();
  const [row] = await db.select().from(admins).where(eq(admins.email, normalized)).limit(1);
  return Boolean(row);
}

export type AdminUser = ChatGPTUser & { isDefaultAdmin: boolean };

/** Returns the signed-in user if they are an allowed admin, otherwise null. Never redirects. */
export async function getAdminUser(): Promise<AdminUser | null> {
  const user = await getChatGPTUser();
  if (!user) return null;
  const isDefaultAdmin = isDefaultAdminEmail(user.email);
  if (isDefaultAdmin) return { ...user, isDefaultAdmin: true };
  const allowed = await isAllowedAdminEmail(user.email).catch(() => false);
  return allowed ? { ...user, isDefaultAdmin: false } : null;
}

/**
 * For pages: sends anonymous visitors to sign-in, and signed-in-but-not-admin
 * visitors to a clear "no access" page (never a silent redirect loop back to
 * sign-in, which would look broken).
 */
export async function requireAdminUser(returnTo: string): Promise<AdminUser> {
  const admin = await getAdminUser();
  if (admin) return admin;
  const user = await getChatGPTUser();
  if (!user) redirect(chatGPTSignInPath(returnTo));
  redirect("/access-denied");
}
