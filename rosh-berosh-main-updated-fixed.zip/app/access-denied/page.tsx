import { getChatGPTUser, chatGPTSignOutPath } from "../chatgpt-auth";

export const dynamic = "force-dynamic";

export default async function AccessDenied() {
  const user = await getChatGPTUser();

  return (
    <main dir="rtl" style={{ maxWidth: 480, margin: "80px auto", textAlign: "center", fontFamily: "system-ui, sans-serif", padding: "0 24px" }}>
      <h1 style={{ fontSize: 24, marginBottom: 12 }}>אין לך הרשאת ניהול</h1>
      <p style={{ color: "#555", lineHeight: 1.6 }}>
        {user ? <>מחובר/ת בתור <strong>{user.email}</strong>, אבל הכתובת הזו אינה ברשימת המנהלים.</> : "יש להתחבר עם משתמש שמורשה לנהל את המערכת."}
        {" "}פנה/י למנהל קיים כדי שיוסיף אותך דרך מסך „ניהול מנהלים”.
      </p>
      {user && (
        <p style={{ marginTop: 24 }}>
          <a href={chatGPTSignOutPath("/")} style={{ color: "#5b5bd6" }}>התנתקות והתחברות עם משתמש אחר</a>
        </p>
      )}
    </main>
  );
}
