"use client";

import { useEffect, useMemo, useState } from "react";

type Survey = { id: string; title: string; status: string; question: string; type: string; options: string[]; channels: string[] };

const VOTER_ID_KEY = "rb_voter_id";
const VOTED_SURVEYS_KEY = "rb_voted_surveys";

function getVoterId(): string {
  try {
    let id = localStorage.getItem(VOTER_ID_KEY);
    if (!id) { id = crypto.randomUUID(); localStorage.setItem(VOTER_ID_KEY, id); }
    return id;
  } catch { return crypto.randomUUID(); }
}

function getVotedIds(): Set<string> {
  try { return new Set(JSON.parse(localStorage.getItem(VOTED_SURVEYS_KEY) || "[]")); } catch { return new Set(); }
}

function markVoted(id: string) {
  try {
    const ids = getVotedIds();
    ids.add(id);
    localStorage.setItem(VOTED_SURVEYS_KEY, JSON.stringify([...ids]));
  } catch { /* localStorage unavailable - vote still submitted server-side */ }
}

function SurveyCard({ survey, alreadyVoted, onVoted }: { survey: Survey; alreadyVoted: boolean; onVoted: (id: string) => void }) {
  const [singleChoice, setSingleChoice] = useState("");
  const [multiChoice, setMultiChoice] = useState<string[]>([]);
  const [ranking, setRanking] = useState<string[]>(survey.options);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [done, setDone] = useState(alreadyVoted);

  const moveOption = (index: number, direction: -1 | 1) => {
    const next = [...ranking];
    const target = index + direction;
    if (target < 0 || target >= next.length) return;
    [next[index], next[target]] = [next[target], next[index]];
    setRanking(next);
  };

  const toggleMulti = (option: string) => {
    setMultiChoice((current) => current.includes(option) ? current.filter((item) => item !== option) : [...current, option]);
  };

  const submit = async () => {
    const answers = survey.type === "single" ? [singleChoice] : survey.type === "multiple" ? multiChoice : ranking;
    if (survey.type === "single" && !singleChoice) { setError("יש לבחור תשובה."); return; }
    if (survey.type === "multiple" && multiChoice.length === 0) { setError("יש לבחור לפחות תשובה אחת."); return; }
    setBusy(true); setError("");
    try {
      const response = await fetch("/api/votes", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ surveyId: survey.id, voterKey: getVoterId(), answers, channel: "site" }),
      });
      const result = await response.json();
      if (response.status === 409) { markVoted(survey.id); setDone(true); onVoted(survey.id); return; }
      if (!response.ok) throw new Error(result.error || "ההצבעה נכשלה.");
      markVoted(survey.id); setDone(true); onVoted(survey.id);
    } catch (caught) { setError(caught instanceof Error ? caught.message : "אירעה שגיאה."); }
    finally { setBusy(false); }
  };

  if (done) {
    return (
      <div className="vote-card">
        <h3>{survey.title}</h3>
        <p className="vote-thanks">תודה, הצבעתך בסקר הזה נקלטה. ✓</p>
      </div>
    );
  }

  return (
    <div className="vote-card">
      <h3>{survey.title}</h3>
      <p className="vote-question">{survey.question}</p>

      {survey.type === "single" && (
        <div>
          {survey.options.map((option) => (
            <label key={option} className={`vote-option ${singleChoice === option ? "selected" : ""}`}>
              <input type="radio" name={`survey-${survey.id}`} checked={singleChoice === option} onChange={() => setSingleChoice(option)} />
              {option}
            </label>
          ))}
        </div>
      )}

      {survey.type === "multiple" && (
        <div>
          {survey.options.map((option) => (
            <label key={option} className={`vote-option ${multiChoice.includes(option) ? "selected" : ""}`}>
              <input type="checkbox" checked={multiChoice.includes(option)} onChange={() => toggleMulti(option)} />
              {option}
            </label>
          ))}
        </div>
      )}

      {survey.type === "ranking" && (
        <div>
          <p className="vote-hint">סדרו מהמקום הראשון (למעלה) לאחרון, בעזרת החצים.</p>
          {ranking.map((option, index) => (
            <div key={option} className="vote-option">
              <span className="vote-rank">{index + 1}</span>
              <span style={{ flex: 1 }}>{option}</span>
              <button type="button" className="vote-rank-btn" disabled={index === 0} onClick={() => moveOption(index, -1)} aria-label="הזז למעלה">▲</button>
              <button type="button" className="vote-rank-btn" disabled={index === ranking.length - 1} onClick={() => moveOption(index, 1)} aria-label="הזז למטה">▼</button>
            </div>
          ))}
        </div>
      )}

      {error && <p className="form-error">{error}</p>}
      <button className="primary vote-submit" disabled={busy} onClick={submit}>{busy ? "שולח..." : "שלח הצבעה"}</button>
    </div>
  );
}

export default function VotePage() {
  const [surveys, setSurveys] = useState<Survey[]>([]);
  const [loading, setLoading] = useState(true);
  const [votedIds, setVotedIds] = useState<Set<string>>(new Set());

  useEffect(() => {
    setVotedIds(getVotedIds());
    (async () => {
      try {
        const response = await fetch("/api/surveys?published=1", { cache: "no-store" });
        if (response.ok) {
          const { surveys: all } = await response.json();
          setSurveys((all ?? []).filter((s: Survey) => Array.isArray(s.channels) && s.channels.includes("site")));
        }
      } finally { setLoading(false); }
    })();
  }, []);

  const openSurveys = useMemo(() => surveys, [surveys]);

  return (
    <main className="vote-page" dir="rtl">
      <div className="vote-header">
        <h1>הצבעה</h1>
        <p>בחרו סקר וענו — ההצבעה נשמרת מיד.</p>
      </div>

      {loading && <p className="vote-hint" style={{ textAlign: "center" }}>טוען סקרים...</p>}
      {!loading && openSurveys.length === 0 && <p className="vote-hint" style={{ textAlign: "center" }}>אין כרגע סקרים פתוחים להצבעה באתר.</p>}

      {openSurveys.map((survey) => (
        <SurveyCard key={survey.id} survey={survey} alreadyVoted={votedIds.has(survey.id)} onVoted={(id) => setVotedIds((current) => new Set(current).add(id))} />
      ))}
    </main>
  );
}
