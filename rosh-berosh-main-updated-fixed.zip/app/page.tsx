import { requireAdminUser } from "./admin";
import DashboardClient from "./dashboard-client";

// Protected page: only emails in the admin allowlist reach the dashboard.
// Anonymous visitors are sent to sign in; signed-in non-admins are sent to
// /access-denied. See app/admin.ts for the allowlist itself.
export const dynamic = "force-dynamic";

export default async function Home() {
  const admin = await requireAdminUser("/");
  return <DashboardClient displayName={admin.displayName} adminEmail={admin.email} isDefaultAdmin={admin.isDefaultAdmin} />;
}
