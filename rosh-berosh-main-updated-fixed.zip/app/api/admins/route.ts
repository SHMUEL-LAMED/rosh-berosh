import { eq } from "drizzle-orm";
import { getDb } from "../../../db";
import { admins } from "../../../db/schema";
import { getAdminUser, isDefaultAdminEmail, DEFAULT_ADMIN_EMAILS } from "../../admin";

function normalizeEmail(email: string): string {
  return email.trim().toLowerCase();
}

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export async function GET() {
  const admin = await getAdminUser();
  if (!admin) return Response.json({ error: "אין הרשאה." }, { status: 403 });

  const db = await getDb();
  const rows = await db.select().from(admins);
  const dbAdmins = rows.map((row) => ({ email: row.email, addedBy: row.addedBy, createdAt: row.createdAt, isDefault: false }));
  const bootstrapAdmins = DEFAULT_ADMIN_EMAILS
    .filter((email) => !rows.some((row) => row.email === normalizeEmail(email)))
    .map((email) => ({ email: normalizeEmail(email), addedBy: null, createdAt: null, isDefault: true }));

  return Response.json({ admins: [...bootstrapAdmins, ...dbAdmins] });
}

export async function POST(request: Request) {
  const admin = await getAdminUser();
  if (!admin) return Response.json({ error: "אין הרשאה." }, { status: 403 });

  const body = await request.json() as Record<string, unknown>;
  const email = normalizeEmail(String(body.email ?? ""));
  if (!email || !EMAIL_PATTERN.test(email)) return Response.json({ error: "כתובת אימייל לא תקינה." }, { status: 400 });

  const db = await getDb();
  try {
    await db.insert(admins).values({ email, addedBy: admin.email });
  } catch {
    return Response.json({ error: "המשתמש כבר ברשימת המנהלים." }, { status: 409 });
  }
  return Response.json({ ok: true }, { status: 201 });
}

export async function DELETE(request: Request) {
  const admin = await getAdminUser();
  if (!admin) return Response.json({ error: "אין הרשאה." }, { status: 403 });

  const body = await request.json() as Record<string, unknown>;
  const email = normalizeEmail(String(body.email ?? ""));
  if (!email) return Response.json({ error: "חסרה כתובת אימייל." }, { status: 400 });
  if (isDefaultAdminEmail(email)) return Response.json({ error: "לא ניתן להסיר מנהל ברירת מחדל." }, { status: 400 });
  if (email === normalizeEmail(admin.email)) return Response.json({ error: "לא ניתן להסיר את עצמך." }, { status: 400 });

  const db = await getDb();
  await db.delete(admins).where(eq(admins.email, email));
  return Response.json({ ok: true });
}
