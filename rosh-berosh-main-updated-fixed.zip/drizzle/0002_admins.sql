CREATE TABLE `admins` (
	`email` text PRIMARY KEY NOT NULL,
	`added_by` text,
	`created_at` integer DEFAULT (unixepoch()) NOT NULL
);
