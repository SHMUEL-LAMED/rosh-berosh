import { eq } from "drizzle-orm";
import { getDb } from "../../../../../db";
import { surveys } from "../../../../../db/schema";

// Yemot HaMashiach (ימות המשיח) does not support playing audio from an external
// URL - every file that should be played over the phone must physically live
// inside their own storage. So when an admin uploads a recording here, we push
// it straight into the customer's Yemot account via their UploadFile API, and
// store the resulting in-system path (e.g. "ivr2:/100/S-abcdef.wav") on the
// survey row. The phone IVR service later references that same path with a
// `file` message when it plays the question to a caller.

const YEMOT_BASE_URL = process.env.YEMOT_BASE_URL || "https://www.call2all.co.il/ym/api";

export async function POST(request: Request, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;

  const token = process.env.YEMOT_TOKEN; // format: "0771234567:1234"
  const folder = process.env.YEMOT_AUDIO_FOLDER; // e.g. "100" - an ivr2 extension folder dedicated to survey recordings
  if (!token || !folder) {
    return Response.json(
      { error: "החיבור לימות המשיח לא הוגדר בשרת (חסרים YEMOT_TOKEN / YEMOT_AUDIO_FOLDER)." },
      { status: 500 },
    );
  }

  const db = await getDb();
  const [survey] = await db.select().from(surveys).where(eq(surveys.id, id)).limit(1);
  if (!survey) return Response.json({ error: "הסקר לא נמצא." }, { status: 404 });

  const incoming = await request.formData();
  const file = incoming.get("audio");
  if (!(file instanceof File)) return Response.json({ error: "לא צורף קובץ הקלטה." }, { status: 400 });

  const yemotPath = `ivr2:/${folder}/${survey.id}.wav`;

  const upload = new FormData();
  upload.append("file", file, `${survey.id}.wav`);

  const uploadUrl = `${YEMOT_BASE_URL}/UploadFile?token=${encodeURIComponent(token)}&path=${encodeURIComponent(yemotPath)}&convertAudio=1`;

  let yemotResult: { responseStatus?: string; message?: string } = {};
  try {
    const yemotResponse = await fetch(uploadUrl, { method: "POST", body: upload });
    yemotResult = await yemotResponse.json();
  } catch {
    await db.update(surveys).set({ audioStatus: "error" }).where(eq(surveys.id, id));
    return Response.json({ error: "לא ניתן היה להתחבר לשרת ימות המשיח." }, { status: 502 });
  }

  if (yemotResult.responseStatus !== "OK") {
    await db.update(surveys).set({ audioStatus: "error" }).where(eq(surveys.id, id));
    return Response.json({ error: yemotResult.message || "ימות המשיח דחו את ההעלאה." }, { status: 502 });
  }

  await db.update(surveys).set({ audioPath: yemotPath, audioStatus: "uploaded" }).where(eq(surveys.id, id));
  return Response.json({ ok: true, audioPath: yemotPath });
}
