ALTER TABLE `surveys` ADD `audio_path` text;--> statement-breakpoint
ALTER TABLE `surveys` ADD `audio_status` text DEFAULT 'missing' NOT NULL;